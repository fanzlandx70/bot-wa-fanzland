let handler = async m => m.reply(`
╭─「 Donasi • Pulsa 」
│ • Indosat Ooredoo [085697880392]
│ • Telkomsel [0895622813191]
╰────

╭─「 Donasi • Non Pulsa 」
│ • Gopay, OVO, Dana [085697880392]
│ • https://saweria.co/Fanzlandx70
╰────
`.trim()) // Tambah sendiri kalo mau
handler.help = ['donasi']
handler.tags = ['info']
handler.command = /^dona(te|si)$/i

module.exports = handler
